function [gbest, gbestval, nfe, RecordT] = TSMSDE_Def_func(fhd, D, nfe_max, Xmin, Xmax, varargin)
    % Hirarchical ARchive DE with pet (HARD-DE-pet)
    % F = 0.5, CR = 0.5, numst = D;
    %%
    fidvec = cell2mat(varargin);
    fid = fidvec(1);
    runid = fidvec(2);
    WriteFlag = true;
    if WriteFlag
        targetbest = [100;200;300;400;500;600;700;800;900;1000;1100;1200;
1300;1400;1500;1600;1700;1800;1900;2000;2100;2200;2300;2400;2500;2600;2700;2800;2900;3000];
        name = ['TSMSDE_Def_', num2str(fid), '_', num2str(D), 'D_', num2str(runid), '.dat'];
        fout = fopen(name, 'a');
    end
    % random seed
    stm = RandStream('swb2712', 'Seed', sum(100*clock));
    RandStream.setGlobalStream(stm);
    
    % ���������������������ֵ
    tau = 0.3 * nfe_max;
    
    tic;
    % ��������
    ps_ini = round(25 * log(D) * sqrt(D));
    ps = ps_ini;
    numStra = 4;
    ps_min = numStra;
    
    % ��ʼ��
    pos = Xmin + (Xmax - Xmin) .* rand(ps/2, D);
    opposite_population = Xmin + Xmax - pos;  % ���������
    pos = [pos; opposite_population];  % �ϲ���Ⱥ�Ͷ�����Ⱥ
    % ѡȡǰps������
    pos = pos(1:ps, :);
%   pos = Xmin + (Xmax-Xmin).*rand(ps,D);
    eval = feval(fhd, pos', fid);  % ����ֵΪ��Ⱥ��С������
    nfe = ps;
    pbest = pos;
    pbestval = eval;
    [gbestval, gbestid] = min(pbestval);
    gbest = pos(gbestid, :);
    if WriteFlag
        fprintf(fout, '%d\t%.15f\n', 1, gbestval - targetbest(fid));
    end    

    F = 0.3;
    Cr = 0.8;
    FVector = F * ones(1, numStra);
    CrVector = Cr * ones(1, numStra);
    probStra = ones(1, numStra);
    Archfactor = 1;
    ArchfactorB = 4;
    
    pStart = 0.25;
    pCurr = pStart;
    pEnd = 0.11;
    pminN = 2;

    A = [];
    B = [];
    gen = 2;
    pivot = [2/3 * nfe_max, 1/3 * ps_ini];
    counter = zeros(ps, 1);
    meanInt = mean(pbest);
    numG = 2 * D;
    DI_ini = sqrt(sum(pdist2(meanInt, pbest)));
    Seed_store = [];
    Seedval_store = [];
    once = 1;

    while nfe < nfe_max
        [~, indexSel] = sort(pbestval);
        pNP = max(round(pCurr * ps), pminN);
        lenSel = max(ceil(pNP * rand(1, ps)), 1);
        pbestIndex = zeros(ps, 1);
        for idx = 1:ps
            pbestIndex(idx) = indexSel(lenSel(idx));
        end
        pbestB = pos(pbestIndex, :);
        
        if gen > 2
            pbest(indexSel(ps + 1:end), :) = [];
            pos = pbest;
            pbestval(indexSel(ps + 1:end)) = [];
            if size(A, 1) > round(Archfactor * ps)
                A = A(1:round(Archfactor * ps), :);
            end
            if size(B, 1) > round(ArchfactorB * ps)
                B = B(1:round(ArchfactorB * ps), :);
            end
        end
        
        rndBase = randperm(ps)';
        psExt = ps + size(A, 1);
        rndSeq1 = ceil(rand(ps, 1) * psExt);
        psExtB = ps + size(B, 1);
        rndSeq2 = ceil(rand(ps, 1) * psExtB);
        for ii = 1:ps
            while rndBase(ii) == ii
                rndBase(ii) = ceil(rand() * ps);
            end
            while rndSeq1(ii) == rndBase(ii) || rndSeq1(ii) == ii
                rndSeq1(ii) = ceil(rand() * psExt);
            end
            while rndSeq2(ii) == rndSeq1(ii) || rndSeq2(ii) == rndBase(ii) || rndSeq2(ii) == ii
                rndSeq2(ii) = ceil(rand() * psExtB);
            end
        end
        posx = [pos; A];
        posxB = [pos; B];
        posr = pos(rndBase, :);
        posxr = posx(rndSeq1, :);
        posxr1 = posxB(rndSeq2, :);
        
       %% �����ʷֲ���������ӵ���ͬ��������
        % stochastic universal sampling for strategy chosen.
        normProb = probStra / sum(probStra);
        spacing = 1 / ps;
        randnums = (rand:1:ps) * spacing;
        cumProb = 0;    % cumulative probability
        
        labelStra = zeros(ps, 1);
        pop2stra = zeros(ps, 1);
        numDistCount = zeros(1, numStra);

        for ii = 1:numStra
            cumProb = cumProb + normProb(ii);
            labelStra = ~labelStra & (randnums < cumProb)';
            numDistCount(ii) = numel(labelStra(labelStra == 1));
            pop2stra = pop2stra + labelStra * ii;
            labelStra = labelStra | pop2stra;  % ��ɶ�ֵԪ�ء�
        end
        
       %% ����CrMat��FMat
        FCol = zeros(ps, 1);
        CrCol = zeros(ps, 1);
        mean_fitness = mean(pbestval);
        std_fitness = std(pbestval);
        [~, rank_idx] = sort(pbestval);
        for ii = 1:ps
            if nfe < tau
                % ���ڽ׶Σ��������
                FCol(ii) = 0.5 + 0.3 * rand();
            elseif nfe < 2 * tau
                % ���ڽ׶Σ�����������������
                fitness_diff = abs(pbestval(ii) - mean_fitness);
                rank = find(rank_idx == ii);
                rank_factor = (ps - rank) / ps; % �����������ӣ���Χ�� [0, 1] ֮��

                if fitness_diff > std_fitness
                    F_temp = 0.6 + 0.3 * rand(); % ����Fֵ����ǿ̽������
                else
                    F_temp = 0.3 + 0.3 * rand(); % ��СFֵ����ǿ��������
                end
                FCol(ii) = (F_temp + (0.3 + 0.6 * rank_factor)) / 2; % �ۺϵ���F
                FCol(ii) = min(max(FCol(ii), 0.1), 0.9); % ȷ��F��[0.1, 0.9]��Χ��
            else
                % ���ڽ׶Σ��̶�������Ӧ����
                FCol(ii) = randCauchy(FVector(pop2stra(ii)), 0.1);
                while FCol(ii) <= 0
                    FCol(ii) = randCauchy(FVector(pop2stra(ii)), 0.1);
                end
                if FCol(ii) > 1
                    FCol(ii) = 1;
                end
            end
            CrCol(ii) = max(0, min(normrnd(CrVector(pop2stra(ii)), 0.1), 1));
        end
        FMat = repmat(FCol, 1, D);

        label = zeros(ps, D);
        rndVal = rand(ps, D);
        onemat = zeros(ps, D);
                
        for ii = 1:ps
            label(ii, :) = rndVal(ii, :) <= CrCol(ii);
            indexJ = ceil(rand() * D);
            onemat(ii, indexJ) = 1;
        end
        label = label | onemat;
        if nfe < pivot(1)
            pos = pbest + FMat .* (pbestB - pbest) + 0.9 * FMat .* (posr - posxr1);
           % pos = pbest + FMat .* (pbestB - pbest) + 0.9 * FMat .* (posr - posxr1);
          % pos = pbest + FMat.*(pbestB-pbest)+0.9*FMat.*(posr-posxr)+0.9*FMat.*(posr-posxr1);
        else
            pos = pbest + FMat .* (pbestB - pbest) + FMat .* (posr - posxr);
            if once == 1
                F = 0.6;
                CrVector = 0.8 * ones(1, numStra);
                once = 0;
            end
        end
        
        pos(~label) = pbest(~label);
        pos = ((pos >= Xmin) & (pos <= Xmax)) .* pos ...
              + (pos < Xmin) .* ((Xmin + pbest) .* rand(ps, D) / 2) ...
              + (pos > Xmax) .* ((Xmax + pbest) .* rand(ps, D) / 2);
               
        eval = feval(fhd, pos', fid);
        nfe = nfe + ps;
        bin = (pbestval > eval)';
        diff = (pbestval - eval)';
        vdiff = pos - pbest;
        udiff = vdiff .* label;
        
        usucc = udiff(bin == 1, :);
        weiFCR = std(usucc, 0, 2);
        weiFCR = weiFCR / sum(weiFCR);
        
        A = [A; pbest(bin == 1, :)];
        maxASize = round(Archfactor * ps);
        if size(A, 1) > round(Archfactor * ps)
            A_eval = feval(fhd,A',fid);
            [~, idx] = sort(A_eval, 'ascend');
            A = A(idx(1:maxASize), :);
        end

        B = [B; pbest];
        maxBSize = round(ArchfactorB * size(A, 1));
        if size(B, 1) > maxBSize
            B_eval = feval(fhd, B', fid);
            [~, idx] = sort(B_eval, 'ascend');
            B = B(idx(1:maxBSize), :);
        end
        
        pbest(bin == 1, :) = pos(bin == 1, :);
        pbestval(bin == 1) = eval(bin == 1);
        diffB = diff(bin == 1);
        
        Succ = pop2stra(bin);
        FToRecord = FMat(bin, 1);
        CrToRecord = CrCol(bin, 1);
        nSucc = zeros(1, numStra);
        Meanpos = mean(pbest);
        DI = sqrt(sum(pdist2(Meanpos, pbest)));
        RDI = DI / DI_ini;

        if round(RDI * 10) == 6
            num = round(0.15 * ps);
            nums = ceil(ps * rand(num, 1));
            numst = pbest(nums, :);
            Seed_store = [Seed_store; numst];
            Seedval_store = [Seedval_store; pbestval'];
        end
        num_seed = size(Seed_store, 1);

        if ~isempty(Succ)
            for ii = 1:numStra
                labelF = (Succ == ii);
                valF = diffB(labelF);
                nSucc(ii) = numel(valF);
            end
            F = weiFCR' * (FToRecord.^2) / (weiFCR' * FToRecord);
            nFail = numDistCount - nSucc;
            for ii = 1:numStra
                % Selection probability update.
                if (nSucc(ii) + nFail(ii) == 0)
                    probStra(ii) = 0.001;
                else
                    probStra(ii) = nSucc(ii)^2 / (sum(nSucc) * (nSucc(ii) + nFail(ii))) + 0.01;
                end        
            end
            loc = find(probStra == min(probStra));
            indexLoc = loc(max(round(rand() * numel(loc)), 1));
            if max(CrToRecord) == 0 || CrVector(indexLoc) == -1
                CrVector(indexLoc) = -1;
            else
                CrVector(indexLoc) = weiFCR' * (CrToRecord.^2) / (weiFCR' * CrToRecord);
            end
        end
        FVector = repmat(F, 1, numStra);
        [gbestval, gbestid] = min(pbestval);
        gbest = pbest(gbestid, :);
        pos = pbest;
        
        for i = 1:ps
            if bin(i) == 0
                counter(i) = counter(i) + 1;
            else
                counter(i) = 0;
            end
        end 
        if RDI < 0.001
            for i = 1:ps
                if counter(i) >= numG && i ~= gbestid
                    if num_seed ~= 0
                        seed_selec1 = ceil(rand() * num_seed);
                        seed_selec2 = ceil(rand() * num_seed);
                        seed_selec3 = ceil(rand() * num_seed);
                        while seed_selec2 == seed_selec1
                            seed_selec2 = ceil(rand() * num_seed);
                        end
                        while seed_selec3 == seed_selec2 || seed_selec3 == seed_selec1 
                            seed_selec3 = ceil(rand() * num_seed);
                        end
                        F_div = randCauchy(0.5, 0.1);
                        pbest(i, :) = Seed_store(seed_selec1, :) + F_div * (Seed_store(seed_selec2, :) - Seed_store(seed_selec3, :));
                        pbestval(i) = feval(fhd, pbest(i, :)', varargin{:});
                        nfe = nfe + 1;
                    else
                        pbest(i, :) = Xmin + (Xmax - Xmin) .* rand(1, D);
                        pbestval(i) = feval(fhd, pbest(i, :)', fid);
                        nfe = nfe + 1;
                    end
                    counter(i) = 0;     
                end
            end
        end
        
        if ((mod(nfe - ps, 100 * 5 * D) >= 100 * 5 * D - ps) && mod(nfe, 100 * 5 * D) < ps)
            fprintf(fout, '%d\t%.15f\n', nfe, gbestval - targetbest(fid));
        end

        if nfe < pivot(1)
            ps = ceil((pivot(2) - ps_ini) / (pivot(1) - ps_ini)^2 * (nfe - ps_ini)^2 + ps_ini);
        else
            ps = floor((pivot(2) - ps_min) / (pivot(1) - nfe_max) * (nfe - nfe_max) + ps_min);
        end
        if ps < ps_min
            ps = ps_min;
        end
        pCurr = pStart + (pEnd - pStart) * nfe / nfe_max;
        gen = gen + 1;
    end
    RecordT = toc;
    fclose(fout);
end

function result = randCauchy(mu, sigma)
    [m, n] = size(mu);
    result = mu + sigma * tan(pi * (rand(m, n) - 0.5));
end


